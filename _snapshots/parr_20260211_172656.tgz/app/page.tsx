import HomeHero from "@/components/home/HomeHero";
import HomeServicesGrid from "@/components/home/HomeServicesGrid";
import BookingCTA from "@/components/shared/BookingCTA";
import HomeIntelTeaser from "@/components/home/HomeIntelTeaser";
import SiteFooter from "@/components/SiteFooter";

export default function HomePage() {
  return (
    <main className="bg-black text-white">
      <HomeHero />
      <HomeServicesGrid />
      <BookingCTA />
      <HomeIntelTeaser />
      <SiteFooter />
    </main>
  );
}
