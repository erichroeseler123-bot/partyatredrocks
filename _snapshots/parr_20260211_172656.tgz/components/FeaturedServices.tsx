import Link from "next/link";

type Card = {
  group: "Red Rocks";
  title: string;
  price: string;
  note: string;
  bullets: string[];
  href: string;
  cta: string;
  tone: "shared" | "suv" | "sprinter" | "bus";
};

const CARDS: Card[] = [
  // ---------------- RED ROCKS ----------------
  {
    group: "Red Rocks",
    title: "Group coach seats",
    price: "$59–$65",
    note: "per person",
    bullets: ["Denver pickup windows", "Professional driver + clean timing", "Best value for most groups"],
    href: "/book-shuttle",
    cta: "Reserve seats",
    tone: "shared",
  },
  {
    group: "Red Rocks",
    title: "Private SUV",
    price: "$499",
    note: "flat rate",
    bullets: ["Just your group", "Flexible pickup timing", "Direct return after the show"],
    href: "/private-suburban",
    cta: "Book Private SUV",
    tone: "suv",
  },
  {
    group: "Red Rocks",
    title: "Sprinter van",
    price: "$699",
    note: "flat rate",
    bullets: ["More room + more comfort", "Ideal for larger groups", "Direct pickup + direct return"],
    href: "/book",
    cta: "Request Sprinter",
    tone: "sprinter",
  },
  {
    group: "Red Rocks",
    title: "20-passenger bus",
    price: "$1,099",
    note: "flat rate",
    bullets: ["Big groups, one vehicle", "Best for corporate / birthdays", "Direct pickup + direct return"],
    href: "/book",
    cta: "Request bus",
    tone: "bus",
  },
];

function badge(tone: Card["tone"]) {
  const base =
    "inline-flex items-center rounded-full border px-2.5 py-1 text-[10px] font-black uppercase tracking-[0.22em]";
  switch (tone) {
    case "shared":
      return <span className={`${base} border-zinc-600/60 bg-zinc-900/35 text-zinc-200`}>Shared ride</span>;
    case "suv":
      return <span className={`${base} border-red-500/30 bg-red-500/10 text-red-100`}>Private</span>;
    case "sprinter":
      return <span className={`${base} border-cyan-500/30 bg-cyan-500/10 text-cyan-100`}>Group vehicle</span>;
    case "bus":
      return <span className={`${base} border-violet-500/30 bg-violet-500/10 text-violet-100`}>Large group</span>;
  }
}

function CardUI({ c }: { c: Card }) {
  return (
    <div className="bg-surface border-soft shadow-soft rounded-3xl p-6 transition-all duration-300 hover:-translate-y-1 hover:glow-accent">
      <div className="flex items-start justify-between gap-4">
        <div className="min-w-0">
          {badge(c.tone)}
          <h3 className="mt-3 text-xl md:text-2xl font-black tracking-tight">{c.title}</h3>
        </div>

        <div className="text-right shrink-0">
          <div className="text-2xl md:text-3xl font-black leading-none">{c.price}</div>
          <div className="mt-1 text-[11px] uppercase tracking-[0.22em] text-zinc-400">{c.note}</div>
        </div>
      </div>

      <ul className="mt-5 space-y-2 text-[15px] leading-relaxed text-zinc-200/90">
        {c.bullets.map((b) => (
          <li key={b} className="flex gap-2">
            <span className="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-zinc-400/60" />
            <span>{b}</span>
          </li>
        ))}
      </ul>

      <div className="mt-6">
        <Link
          href={c.href}
          className="inline-flex w-full items-center justify-center rounded-full border border-zinc-600/45 bg-zinc-900/25 px-4 py-3 text-xs font-black uppercase tracking-[0.22em] text-zinc-100 hover:bg-zinc-900/40 transition"
        >
          {c.cta}
        </Link>
      </div>
    </div>
  );
}

export default function FeaturedServices() {
  return (
    <section className="relative z-10 max-w-7xl mx-auto px-6 -mt-16 pb-10">
      <div className="bg-surface-strong border-soft shadow-soft rounded-[32px] p-7 md:p-10">
        <div className="flex flex-col lg:flex-row lg:items-end lg:justify-between gap-6">
          <div className="max-w-3xl">
            <p className="text-[12px] font-black uppercase tracking-[0.32em] text-zinc-400">
              Transportation options
            </p>
            <h2 className="mt-3 text-3xl md:text-5xl font-black tracking-tight">
              Would you rather ride with other people — or have a private vehicle just for your group?
            </h2>
            <p className="mt-4 text-[16px] md:text-[18px] leading-relaxed text-zinc-300">
              Fixed pricing, professional drivers, and timing built for show nights. Pick the option that fits your
              group size and vibe.
            </p>
          </div>
        </div>

        <div className="mt-10">
          <div className="flex items-center justify-between gap-4">
            <h3 className="text-sm font-black uppercase tracking-[0.28em] text-zinc-400">Red Rocks</h3>
            <Link href="/book" className="text-xs font-black uppercase tracking-[0.28em] text-zinc-300 hover:text-white">
              Get a quote →
            </Link>
          </div>

          <div className="mt-5 grid gap-5 md:grid-cols-2 xl:grid-cols-4">
            {CARDS.map((c) => (
              <CardUI key={c.title + c.price} c={c} />
            ))}
          

        <div className="mt-8">
          <a href="/other-venues" className="link-blue text-sm font-black uppercase tracking-[0.22em]">
            Going somewhere else? Mishawaka + other venues →
          </a>
        </div>

</div>
        </div>
      </div>
    </section>
  );
}
