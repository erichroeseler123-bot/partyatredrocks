import Link from "next/link";

export default function ShuttleCTA({
  title = "Ready for Your Red Rocks Show?",
  blurb = "Skip parking and surges—book our $59 round-trip shuttle.",
  href = "/book-shuttle",
  button = "Book Shuttle → $59",
}: {
  title?: string;
  blurb?: string;
  href?: string;
  button?: string;
}) {
  return (
    <div className="my-10 p-6 bg-zinc-900/50 border border-red-600/40 rounded-2xl text-center rounded-2xl">
      <h3 className="text-2xl font-black text-red-500 mb-3">{title}</h3>
      <p className="text-zinc-300 mb-6 max-w-2xl mx-auto">{blurb}</p>
      <Link
        href={href}
        className="inline-block bg-red-600 hover:bg-red-500 px-8 py-4 font-black uppercase rounded-full shadow-xl transition"
      >
        {button}
      </Link>
    </div>
  );
}
