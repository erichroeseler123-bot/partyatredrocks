import Link from "next/link";

export default function BookingCTA({ text = "Book Red Rocks Shuttle — $59/pp" }) {
  return (
    <div className="mx-auto max-w-7xl px-6 my-12">
      <div className="rounded-3xl border border-white/10 bg-white/5 p-8 text-center shadow-2xl">
        <Link
          href="/book-shuttle"
          className="inline-flex items-center justify-center rounded-full px-10 py-4 font-black uppercase tracking-[0.18em] bg-red-600 text-white shadow-xl hover:translate-y-[-1px]"
        >
          {text}
        </Link>
        <div className="mt-3 text-sm text-zinc-300">
          Seats fill fast on sold-out shows. Lock it in now.
        </div>
      </div>
    </div>
  );
}
