// components/utilities/ConcertCalendar.tsx
import Link from 'next/link';

type Event = { artist: string; date: string; venue: string; slug: string };

const staticData: Event[] = [
  { artist: 'CRANKDAT', date: '2026-03-27', venue: 'Red Rocks', slug: 'crankdat' },
  { artist: 'Ravenscoon', date: '2026-03-28', venue: 'Mission Ballroom', slug: 'ravenscoon' },
  { artist: 'INZO', date: '2026-04-03', venue: 'Ball Arena', slug: 'inzo' },
  // Add 5-10 more for demo
];

export default function ConcertCalendar() {
  const today = new Date();
  const next30Days = new Date(today);
  next30Days.setDate(today.getDate() + 30);

  const upcoming = staticData
    .filter(event => {
      const d = new Date(event.date);
      return d >= today && d <= next30Days;
    })
    .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
    .slice(0, 8);

  return (
    <div className="bg-zinc-900/60 border border-zinc-800 rounded-2xl p-6 mb-10">
      <h3 className="text-xl font-black uppercase mb-5 tracking-tight">Denver Concerts – Next 30 Days</h3>
      <div className="space-y-4">
        {upcoming.map(event => (
          <div key={event.slug} className="flex justify-between items-center">
            <div>
              <p className="font-bold text-white">{event.artist}</p>
              <p className="text-sm text-zinc-400">
                {new Date(event.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })} • {event.venue}
              </p>
            </div>
            <Link
              href="/book-shuttle"
              className="text-xs bg-red-600/20 hover:bg-red-600/40 px-3 py-1.5 rounded-full text-red-400 font-bold transition"
            >
              Book Shuttle
            </Link>
          </div>
        ))}
      </div>
      <div className="mt-5 text-center">
        <Link href="/guide/events/2026-season-preview" className="text-sm text-zinc-400 hover:text-white">
          View full calendar →
        </Link>
      </div>
    </div>
  );
}
